import { DatePipe, NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { MoviesService } from '../../../services/movies.service';

@Component({
  selector: 'app-movies-card',
  standalone: true,
  imports: [DatePipe,NgIf],
  templateUrl: './movies-card.component.html',
  styleUrl: './movies-card.component.css'
})
export class MoviesCardComponent implements OnInit {
  @Input() set setMovie(movie: any) { // setMovie oblige l'initialisation et qu'on n'est sur que c'est rempli
    // sinon problem cycle de vie et on n'essaye d'acceder mais n'est pas encore rempli
  this._movie = movie

}

_movie: any;

  constructor(private movieService: MoviesService) { }


  ngOnInit(): void {


    //console.log('moviesCard : ',this._movie);


  }
  }
