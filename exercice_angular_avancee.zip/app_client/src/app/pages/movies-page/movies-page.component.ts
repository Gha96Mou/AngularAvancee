import { Component, OnInit } from '@angular/core';
import { MoviesCardComponent } from './movies-card/movies-card.component';
import { FormsModule, NgForm } from '@angular/forms';
import { MoviesService } from '../../services/movies.service';
import { MatGridListModule } from '@angular/material/grid-list';
import { map } from 'rxjs';
import { NgFor, NgIf } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-movies-page',
  standalone: true,
  imports: [
    MoviesCardComponent,
    FormsModule,
    MatGridListModule,
    NgIf,
    NgFor,RouterModule ,
  ],
  templateUrl: './movies-page.component.html',
  styleUrl: './movies-page.component.css'
})
export class MoviesPageComponent implements OnInit {

  movies: any[] | undefined;

  constructor(private movieService: MoviesService) { }


  ngOnInit() {
    this.movieService.fetchAll().pipe(
      map(movies => {
        this.movies = movies;
        this.movieService.movieUpdated.subscribe(updatedMovie => {
          if (this.movies) {
            const index = this.movies.findIndex(movie => movie.id === updatedMovie.id);
            if (index !== -1) {
              this.movies[index] = updatedMovie;
            }
          }
        });
      })
    ).subscribe();
  }

createMovie (movie: any) {
  this.movieService.create(movie)
    .subscribe(res => {
      console.log(res);
      this.movies?.push(res);
    });
}

onSubmit(form: NgForm) {
  if (form.valid) {
    this.createMovie(form.value);
    form.resetForm();
  } else {
    console.log('invalid form');
  }
}
}
