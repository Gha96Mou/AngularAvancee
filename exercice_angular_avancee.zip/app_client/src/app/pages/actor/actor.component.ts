import { Component, OnInit } from '@angular/core';
import { ActorService } from '../../services/actor.service';
import { FormsModule, NgForm } from '@angular/forms';
import { DatePipe, NgFor, NgIf } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { ActorCardComponent } from '../actor-card/actor-card.component';

@Component({
  selector: 'app-actor',
  templateUrl: './actor.component.html',
  styleUrls: ['./actor.component.css'],
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    MatGridListModule,
    ActorCardComponent,
    FormsModule,
    DatePipe
]
})
export class ActorComponent implements OnInit {

  actors: any[]|undefined;
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 0;
  showAddActorForm: boolean = false;
  newActor: any = {};
  selectedActor: any;

  constructor(private actorService: ActorService) { }

  ngOnInit() {
    this.fetchActors(this.currentPage);
  }

  fetchActors(page: number) {
    this.actorService.fetchAllPaginated(page, this.pageSize)
      .subscribe(response => {
        this.actors = response.data;
        this.totalPages = Math.ceil(response.total / this.pageSize);
      });
  }

  handlePageChange(pageNumber: number) {
    this.currentPage = pageNumber;
    this.fetchActors(this.currentPage);
  }

  showAddActorFormToggle() {
    this.showAddActorForm = !this.showAddActorForm;
    this.selectedActor = null;
    this.newActor = {}; // Reset new actor object
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.actorService.create(this.newActor)
        .subscribe(res => {
          console.log(res);
          this.fetchActors(this.currentPage); // Rafraîchir la liste des acteurs après l'ajout
          this.showAddActorFormToggle();
        });
    } else {
      alert('Veuillez remplir tous les champs correctement.');
    }
  }


  editActor(actor: any) {
    this.selectedActor = { ...actor };
    this.showAddActorFormToggle();
  }

  updateActor() {
    this.actorService.update(this.selectedActor)
      .subscribe(res => {
        console.log(res);
        this.selectedActor = null;
        this.fetchActors(this.currentPage); // Refresh current page after update
      });
  }
}
