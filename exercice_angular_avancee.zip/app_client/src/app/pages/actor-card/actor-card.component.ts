import { Component, OnInit, Input } from '@angular/core';
import { ActorService } from '../../services/actor.service';
import { DatePipe, NgIf } from '@angular/common';

@Component({
  selector: 'app-actor-card',
  templateUrl: './actor-card.component.html',
  styleUrls: ['./actor-card.component.css'],
  standalone: true,
  imports: [DatePipe,NgIf],
})
export class ActorCardComponent implements OnInit {
  @Input() set setActor(actor: any) { // setActor oblige l'initialisation et qu'on n'est sur que c'est rempli
    // sinon problem cycle de vie et on n'essaye d'acceder mais n'est pas encore rempli
  this._actor = actor;
  console.log('actorCard : ',this._actor);

  }

_actor : any;
  constructor(private actorService: ActorService) { }

  ngOnInit() {
//console.log(this._actor);

    //this.actorService.fetchOne(this.id ?? 0).subscribe(actor => {
     // this.actor = actor;
    //});
  }
}
