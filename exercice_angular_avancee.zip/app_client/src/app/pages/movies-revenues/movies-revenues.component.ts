import { Component, Input, OnInit } from '@angular/core';
import { MoviesRevenuesService } from '../../services/movies-revenues.service';
import { NgFor, NgIf } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { MoviesRevenuesCardComponent } from './movies-revenues-card/movies-revenues-card.component';

@Component({
  selector: 'app-movies-revenues',
  standalone: true,
  imports: [NgIf, NgFor , MoviesRevenuesCardComponent,MatGridListModule],
  templateUrl: './movies-revenues.component.html',
  styleUrl: './movies-revenues.component.css'
})
export class MoviesRevenuesComponent implements OnInit{

  moviesRevenues :any []| undefined;

  constructor(private moviesRevenuesService: MoviesRevenuesService) { }

  ngOnInit(): void {

    this.moviesRevenuesService.fetchAll()
    .subscribe(moviesRevenues => {
      this.moviesRevenues = moviesRevenues;

      console.log('moviesRevenues : ',moviesRevenues);
    })

  }

}
