import { NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { MoviesRevenuesService } from '../../../services/movies-revenues.service';

@Component({
  selector: 'app-movies-revenues-card',
  standalone: true,
  imports: [NgIf],
  templateUrl: './movies-revenues-card.component.html',
  styleUrl: './movies-revenues-card.component.css'
})
export class MoviesRevenuesCardComponent implements OnInit{
  @Input() set setMoviesRevenue(moviesRevenue: any) {
    this._moviesRevenue = moviesRevenue;
}

_moviesRevenue : any;

constructor(private moviesRevenuesService: MoviesRevenuesService) { }

ngOnInit(): void {
  //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
  //Add 'implements OnInit' to the class.
  console.log(this._moviesRevenue);

}
}
