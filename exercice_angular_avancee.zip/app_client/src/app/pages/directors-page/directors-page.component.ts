import { Component, OnInit } from '@angular/core';
import { DirectorsPageService } from '../../services/directors-page.service';
import { NgFor, NgIf } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { DirectoriesCardComponent } from './directories-card/directories-card.component';

@Component({
  selector: 'app-directors-page',
  standalone: true,
  imports: [ NgIf,
    NgFor,
    MatGridListModule,
    DirectoriesCardComponent],

  templateUrl: './directors-page.component.html',
  styleUrl: './directors-page.component.css'
})
export class DirectorsPageComponent implements OnInit {


  directors : any[] | undefined;
  constructor( private directorsPageService: DirectorsPageService) { }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.directorsPageService.fetchAll()
    .subscribe(directors => {
      this.directors = directors;

      console.log(directors);
    })
  }

}
