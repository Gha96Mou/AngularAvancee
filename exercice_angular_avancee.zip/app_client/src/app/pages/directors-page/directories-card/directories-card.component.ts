import { DatePipe, NgFor, NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { DirectorsPageService } from '../../../services/directors-page.service';

@Component({
    selector: 'app-directories-card',
    standalone: true,
    templateUrl: './directories-card.component.html',
    styleUrl: './directories-card.component.css',
    imports: [DatePipe, NgIf, NgFor]
})
export class DirectoriesCardComponent implements OnInit {


  @Input() set setDirector (Director: any) {

    this._Director = Director
  }

  _Director: any;
  constructor(private directorService: DirectorsPageService) { }


  ngOnInit() {

    console.log(this._Director);
  }
}
