import { Routes } from '@angular/router';
import { ActorComponent } from './pages/actor/actor.component';
import { DirectorsPageComponent } from './pages/directors-page/directors-page.component';
import { MoviesRevenuesComponent } from './pages/movies-revenues/movies-revenues.component';
import { MoviesPageComponent } from './pages/movies-page/movies-page.component';
import { HomePageComponent } from './pages/home-page/home-page.component';

export const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'movies', component: MoviesPageComponent },
  { path: 'actors', component: ActorComponent },
  { path: 'directors', component: DirectorsPageComponent },
  { path: 'moviesRevenues', component: MoviesRevenuesComponent },
];
