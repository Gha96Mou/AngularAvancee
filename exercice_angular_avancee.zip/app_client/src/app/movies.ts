export interface Movie{
  id : number;
  name : string;
  length : number;
  lang : string;
  age_certicate : string;
  release_date : Date;
  director_id : number;
}
