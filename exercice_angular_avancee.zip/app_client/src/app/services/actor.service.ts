import { Injectable } from '@angular/core';
import { Observable, Subject, tap } from 'rxjs';
import { environment } from '../environnements';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ActorService {

  constructor(protected http : HttpClient) { }

  public ressourceUrl = environment.apiServerUrl + '/actors';

  fetchAll() : Observable<any> {
    return this.http
    .get<any>(`${this.ressourceUrl}`)
    ;
  }


  actorUpdated = new Subject<any>();

  update(actor: any) {
    return this.http.put(`${this.ressourceUrl}/${actor.id}`, actor)
    .pipe(tap(() => this.actorUpdated.next(actor)));


  }


  create(actor : any) : Observable<any> {
    return this.http
    .post<any>(`${this.ressourceUrl}`, actor)
    ;
  }



}
