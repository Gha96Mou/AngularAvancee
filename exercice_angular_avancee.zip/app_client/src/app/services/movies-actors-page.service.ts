import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environnements';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MoviesActorsPageService {

  constructor(protected http : HttpClient) { }

  public ressourceUrl = environment.apiServerUrl + '/movies-actors'

  fetchAll() : Observable<any> {
    return this.http
    .get<any>(`${this.ressourceUrl}`);
  }
}
