import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from '../environnements'; // Import the environment object correctly

@Injectable({
  providedIn: 'root'
})

export class MoviesService {
  constructor(protected http: HttpClient) { }

  public ressourceUrl = environment.apiServerUrl + '/movies'; // Access the apiServerUrl property correctly

  fetchAll(): Observable<any> {
    return this.http
    .get<any>(`${this.ressourceUrl}`) //  Access the apiServerUrl property correctly, use the back ` and not the font '
  }


  movieUpdated = new Subject<any>();

  create(movie: any): Observable<any> {
    return this.http
    .post<any>(`${this.ressourceUrl}`, movie)
  }

  update(movie: any): Observable<any> {
    return this.http
    .put<any>(`${this.ressourceUrl}/${movie.id}`, movie)
  }
}
