import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environnements';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MoviesRevenuesService {

  constructor(private http : HttpClient) { }

  public ressourceUrl = environment.apiServerUrl + '/movies-revenues'

  fetchAll() : Observable<any> {
    return this.http
    .get<any>(`${this.ressourceUrl}`);
  }
}
