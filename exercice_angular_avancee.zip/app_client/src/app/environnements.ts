export const environment: { apiServerUrl: string } = {
  apiServerUrl: 'http://localhost:3000'
};
