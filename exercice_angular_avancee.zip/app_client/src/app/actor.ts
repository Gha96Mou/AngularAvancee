export interface Actor {
  id: number;
  first_name: string;
  last_name: string;
  gender : "M" | "F";
  date_of_birth : Date;
}
