export interface Director {
  id : number;
  first_name: string;
  last_name: string;
  date_of_birth : Date;
  nationality : string;
}
