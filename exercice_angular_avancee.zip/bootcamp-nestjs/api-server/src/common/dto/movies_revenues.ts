export interface MoviesRevenues {
    id : number;
    movie_id : number;
    revenues_domestic : number;
    revenues_international : number;
}